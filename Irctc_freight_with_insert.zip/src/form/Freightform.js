import React,{ useEffect, useState } from 'react'
import './Freightform.css'
import {useHistory} from "react-router-dom";
import { useForm } from "react-hook-form";
import axios from 'axios'
//import Excellent from '../Assests/Excellent-Train-Wallpaper.jpg';
function Freightform() {
    const history = useHistory();
    //const { register, handleSubmit, watch, formState: { errors } } = useForm();
    //const onSubmit = data => console.log(data);

    const [ftype, setFtype] = useState("")

    const [from, setFromplace] = useState("")

    const [to, setToplace] = useState("")

    const [departure, setDeparture] = useState("")

    const [arrival, setArrival] = useState("")

    const [fname, setFname] = useState("")

    const [errorFt, setErrorFt] = useState("");

    const [errorFp, setErrorFp] = useState("");

    const [errorTp, setErrorTp] = useState("");

    const [errorDe, setErrorDe] = useState("");

    const [errorAr, setErrorAr] = useState("");

    const [errorFn, setErrorFn] = useState("");


    // async function postData(e){

    const validate = (e) => {
        e.preventDefault()
        if (ftype === "") {
            setErrorFt("*Select Freighttype")
        }
        else {
            setErrorFt("")
        }
        if (from === "") {
            setErrorFp("*Select from place")
        }
        else {
            setErrorFp("")
        }
        if (to === "") {
            setErrorTp("*Select to place")
        }
        else {
            setErrorTp("")
        }
        if (departure === "") {
            setErrorDe("*Select departure time")
        }
        else {
            setErrorDe("")
        }
        if (arrival === "") {
            setErrorAr("*Select arrival time")
        }
        else {
            setErrorAr("")
        }
        if (fname === "") {
            setErrorFn("*Give Freightname")
        }
        else {
            setErrorFn("")
        }
        axios.post("http://localhost:8080/insertfreight",
        {ftype,fname,departure,arrival,from,to}
    )
        console.log("testdata")
    alert("")
        // console.log(e);
        
        
        
        //console.log(from);
        //console.log(to);
        //console.log(date);
        //console.log(classes);
        //console.log(general);form-->onSubmit={handleSubmit(onSubmit)}
    }
    // function postData(e){
    //     console.log("test")
    //             e.preventDefault();
    //             try{
    //                 // await axios.post("http://localhost:8080/insertfreight",
    //                 axios.post("http://localhost:8080/insertfreight",
    //             {fname})
    //             console.log("testdata")}
        
    //             catch(error)
    //             {console.log(error)
    //             }
    //             }
    return (
        <div>
            <body className="sanbodypart">
                <form className="sanformpart">
                    {/* {onSubmit={postData}} */}
                    <div>
                        <h1 className="sanheadingtxt">Book Your Freight</h1>
                    </div>
                    <div className="sanfs">
                        {/* <div> */}
                        {/* <!-- <div className="sanlin"><label className="sanlabel" for="id">User ID</label><input className="sanin" type="text" id="id" placeholder="User ID" value=""></div> --> */}
                        {/* <div className="sanlin">
                            <label className="sanlabel1" for="fname">Freight Name</label>
                            <input className="sanin sanselect1" name="fname" type="text" id="fname" placeholder="Freight Name" {...register("fname", {
                                required: 'error message' // JS only: <p>error message</p> TS only support string
                            })} />
                            {errors.fname && (

                                <small className="errorms">{errors.fname.message}</small>

                            )}
                        </div> */}
                        <div className="sanlin">
                            <label className="sanlabel1" for="fname">Freight Name</label>
                            <input className="sanin sanselect1" name="fname" value={fname} type="text" id="fname" placeholder="Freight Name"  onChange={(e) => {
                                setFname(e.target.value)

                                setErrorFn("")

                            }

                            }/><div className='sanerror'>{errorFn === "" ? "" : errorFn}</div>
                            
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="ftype">Type of Freight</label>

                            <select className="sanin sanselect1" name="ftype" value={ftype} id="ftype" onChange={(e) => {
                                setFtype(e.target.value)

                                setErrorFt("")

                            }

                            }>
                                <option>Select</option>
                                <option value="Liquid-Volatile">Liquid-Volatile</option>
                                <option value="Liquid-Non-Volatile">Liquid-Non-Volatile</option>
                                <option value="Solid-Volatile">Solid-Volatile</option>
                                <option value="Solid-Non-Volatile">Solid-Non-Volatile</option>
                                <option value="Gas-Volatile">Gas-Volatile</option>
                                <option value="Gas-Non-Volatile">Gas-Non-Volatile</option>
                            </select>
                            <div className='sanerror'>{errorFt === "" ? "" : errorFt}</div>
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="from">From</label>

                            <select className="sanin sanselect1" name="from" value={from} id="from" onChange={(e) => {
                                setFromplace(e.target.value)

                                setErrorFp("")

                            }

                            }>
                                <option className="sanselect1">Select</option>
                                <option>NEW DELHI - NDLS</option>
                                <option>MGR CHENNAI CTL - MAS</option>
                                <option>HOWRAH JN - HWH</option>
                                <option>SECUNDERABAD JN - SC</option>
                                <option>PUNE JN - PUNE</option>
                                <option>CHENNAI EGMORE - MS</option>
                                <option>MUMBAI CENTRAL - MMCT</option>
                                <option>DELHI - DLI</option>
                                <option>MADURAI JN - MDU</option>
                                <option>TIRUCHCHIRAPALI - TPJ</option>
                            </select>
                            <div className='sanerror'>{errorFp === "" ? "" : errorFp}</div>
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="to">To</label>

                            <select className="sanin sanselect1" name="to" value={to} id="to" onChange={(e) => {
                                setToplace(e.target.value)

                                setErrorTp("")

                            }

                            }>
                                <option className="sanselect1">Select</option>
                                <option>NEW DELHI - NDLS</option>
                                <option>MGR CHENNAI CTL - MAS</option>
                                <option>HOWRAH JN - HWH</option>
                                <option>SECUNDERABAD JN - SC</option>
                                <option>PUNE JN - PUNE</option>
                                <option>CHENNAI EGOMRE - MS</option>
                                <option>MUMBAI CENTRAL - MMCT</option>
                                <option>DELHI - DLI</option>
                                <option>MADURAI JN - MDU</option>
                                <option>TIRUCHCHIRAPALI - TPJ</option>
                            </select>
                            <div className='sanerror'>{errorTp === "" ? "" : errorTp}</div>
                        </div>

                        <div className="sanlin"><label className="sanlabel1" for="departure">Departure</label>
                            <select className="sanin sanselect1"
                                name="departure" value={departure} id="departure" onChange={(e) => {
                                    setDeparture(e.target.value)

                                    setErrorDe("")

                                }

                                }>
                                <option className="sanselect1">Departure</option>
                                <option>Early Morning(0-6)</option>
                                <option>Morning(6-15)</option>
                                <option>Mid Day(12-18)</option>
                                <option>Night(18-24)</option>
                            </select>
                            <div className='sanerror'>{errorDe === "" ? "" : errorDe}</div>
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="arrival">Arrival</label>
                            <select
                                className="sanin sanselect1"
                                name="arrival" value={arrival} id="arrival" onChange={(e) => {
                                    setArrival(e.target.value)

                                    setErrorAr("")

                                }

                                }>
                                <option className="sanselect1">Arrival</option>
                                <option>Early Morning(0-6)</option>
                                <option>Morning(6-15)</option>
                                <option>Mid Day(12-18)</option>
                                <option>Night(18-24)</option>
                            </select>
                            <div className='sanerror'>{errorAr === "" ? "" : errorAr}</div>
                        </div>
                        <div className="sansubmit"><button type="reset" className="sanbtncolor sanuppercase">Reset</button>
                            <button type="submit" className="sanbtncolor sanuppercase" onClick={(e) => validate(e)}>Book My Freight
                            </button>
                            <button type="button" className="sanbtncolor sanuppercase" onClick= {()=>history.push("")}>Back
                            </button>
                        </div>
                        {/* </div> */}
                    </div>
                </form>
            </body>
        </div>
    )
}

export default Freightform
