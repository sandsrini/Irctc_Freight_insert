import logo from './logo.svg';
import './App.css';
import Freight from './Freight';
import Freightform from './form/Freightform';
import {BrowserRouter as Router,Link,Route,Switch} from 'react-router-dom'
import update from './Update';
import Update from './Update';

function App() {
  return (
    <div>
  {/* <Freight/> */}
  <Router>
    <Switch>
    <Route path="/freightform" component={Freightform}/>
    <Route path="" component={Freight}/>
    {/* <Route path="" component={Update}/> */}
    </Switch>
  </Router>
  </div>
  );
}

export default App;
